package com.HomeCare.demo.Config.Security;

import com.HomeCare.demo.Entity.UserMaster;
import com.HomeCare.demo.Repository.UserRepository;
import com.HomeCare.demo.Utils.Constants;
import com.HomeCare.demo.Utils.Exceptions.NotFoundException;
import com.HomeCare.demo.Utils.JwtUtil;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Component
public class JwtRequestFilter extends OncePerRequestFilter {

    @Autowired
    private JwtUtil jwtUtil;

    @Autowired
    private UserRepository userRepository;

    public User loadUserByUsername(String username) throws UsernameNotFoundException {
        UserMaster userMaster = null;
        String password = null;
        Set<String> roles = new HashSet<>();
        userMaster = userRepository.findByEmailAndActive(username,true);
        if (ObjectUtils.isEmpty(userMaster)) {
            throw new NotFoundException(Constants.EMAIL_NOT_EXIST);
        }
        password = userMaster.getUserPassword();
        if (userMaster.getRole().getRoleStatus()) {
            String role = userMaster.getRole().getRoleName();
            role = "ROLE_" + role.toUpperCase();
            roles.add(role);
        }
        List<SimpleGrantedAuthority> grantedAuthorities = roles.stream().map(SimpleGrantedAuthority::new).toList();

        return new User(userMaster.getUserEmail(), password, grantedAuthorities);
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {

        final String authorizationHeader = request.getHeader("Authorization");
        String username = null;
        String jwt = null;

        if (authorizationHeader != null && authorizationHeader.startsWith("Bearer ")) {
            jwt = authorizationHeader.substring(7);
            try {
                username = jwtUtil.getUsernameFromToken(jwt);
            } catch (Exception e) {
                request.setAttribute("exception", e);
            }
            if (username != null && SecurityContextHolder.getContext().getAuthentication() == null) {
                //UserDetails userDetails = null;
                User userDetails = loadUserByUsername(username);
//                UserMaster userDetails = userRepository.findByEmailAndActive();
                if (jwtUtil.validateToken(jwt, userDetails)) {
                    com.HomeCare.demo.Config.Security.JwtTokenHolder.storeToken(jwt);
                    UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken = new UsernamePasswordAuthenticationToken(userDetails, null, userDetails.getAuthorities());
                    usernamePasswordAuthenticationToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
                    SecurityContextHolder.getContext().setAuthentication(usernamePasswordAuthenticationToken);
                }
            }
        }
        filterChain.doFilter(request, response);
    }
}
