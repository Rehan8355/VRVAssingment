package com.HomeCare.demo.Config.Security;

import org.springframework.stereotype.Component;

@Component
public class JwtTokenHolder {
    private static final ThreadLocal<String> jwtTokenThreadLocal = new ThreadLocal<>();

    public static void storeToken(String token) {
        jwtTokenThreadLocal.set(token);
    }

    public static String fetchToken() {
        return jwtTokenThreadLocal.get();
    }

    public static void clearToken() {
        jwtTokenThreadLocal.remove();
    }
}
