package com.HomeCare.demo.Controller.Impl;

import com.HomeCare.demo.Controller.Interfaces.IAuthController;
import com.HomeCare.demo.Model.ChangePasswordRequest;
import com.HomeCare.demo.Model.LoginRequest;
import com.HomeCare.demo.Model.PasswordResetRequest;
import com.HomeCare.demo.Model.ResponseModel.GenericResponse;
import com.HomeCare.demo.Service.Impl.AuthService;
import com.HomeCare.demo.Utils.Constants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;

@RestController
public class AuthController implements IAuthController {

    @Autowired
    private AuthService authService;

    @Override
    public ResponseEntity<GenericResponse<Object>> loginUser(LoginRequest loginRequest) {

        HashMap<String, Object> responseMap = authService.loginAuthUser(loginRequest);
        return new ResponseEntity<>(new GenericResponse<>(responseMap, Constants.SUCCESSFULLY_LOGIN, HttpStatus.OK.value()), HttpStatus.OK);

    }

    @Override
    public ResponseEntity<GenericResponse<Object>> updatePassword(PasswordResetRequest passwordResetRequest) {
        authService.changePassword(passwordResetRequest);
        return new ResponseEntity<>(new GenericResponse<>(Constants.SUCCESS , Constants.PASSWORD_CHANGED_SUCCESSFULLY , HttpStatus.OK.value()), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<GenericResponse<Object>> resetPassword(ChangePasswordRequest changePasswordRequest) {
        authService.resetPassword(changePasswordRequest);
        return new ResponseEntity<>(new GenericResponse<>(Constants.SUCCESS , Constants.PASSWORD_CHANGED_SUCCESSFULLY , HttpStatus.OK.value()) , HttpStatus.OK);
    }
}
