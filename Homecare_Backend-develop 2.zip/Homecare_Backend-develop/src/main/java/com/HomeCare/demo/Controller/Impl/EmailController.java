package com.HomeCare.demo.Controller.Impl;

import com.HomeCare.demo.Controller.Interfaces.IEmailController;
import com.HomeCare.demo.Model.EmailRequest;
import com.HomeCare.demo.Model.OtpVerifyDetails;
import com.HomeCare.demo.Model.ResponseModel.GenericResponse;
import com.HomeCare.demo.Service.Impl.EmailService;
import com.HomeCare.demo.Utils.Constants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;

@RestController
public class EmailController implements IEmailController {

    @Autowired
    private EmailService emailService;


    @Override
    public ResponseEntity<GenericResponse<Object>> sendOtpEmail(EmailRequest emailRequest) {
        HashMap<String , Object> response = emailService.sendOtp(emailRequest);
        return new ResponseEntity<>(new GenericResponse<>(response , Constants.EMAIL_SEND_SUCCESSFULLY, HttpStatus.OK.value()),HttpStatus.OK);
    }

    @Override
    public ResponseEntity<GenericResponse<String>> sendMailWithAttachment(EmailRequest emailRequest) {
        String response = emailService.sendMailWithAttachment(emailRequest);
        return new ResponseEntity<>(new GenericResponse<>(response , Constants.EMAIL_SEND_SUCCESSFULLY, HttpStatus.OK.value()),HttpStatus.OK);
    }

    @Override
    public ResponseEntity<GenericResponse<String>> verifyOtp(OtpVerifyDetails otpVerifyDetails) {
        String response = emailService.otpVerification(otpVerifyDetails);
        return new ResponseEntity<>(new GenericResponse<>(response , Constants.OTP_VERIFICATION_SUCCESSFUL , HttpStatus.OK.value()), HttpStatus.OK);
    }


}
