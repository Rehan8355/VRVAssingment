package com.HomeCare.demo.Controller.Impl;

import com.HomeCare.demo.Controller.Interfaces.IUserController;
import com.HomeCare.demo.Model.ResponseModel.GenericResponse;
import com.HomeCare.demo.Model.PcaListDetails;
import com.HomeCare.demo.Model.PcaPersonalDetails;
import com.HomeCare.demo.Model.SuperAdminProfile;
import com.HomeCare.demo.Model.UserDetails;
import com.HomeCare.demo.Service.Impl.UserService;
import com.HomeCare.demo.Utils.Constants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;

@RestController
public class UserController implements IUserController {
    @Autowired
    private UserService userService;
    @Override
    public ResponseEntity<?> createNewUser(UserDetails userDetails) {
        userService.createUser(userDetails);
        return new ResponseEntity<>(new GenericResponse<>(Constants.USER_CREATED_SUCCESSFULLY, Constants.SUCCESS, HttpStatus.OK.value()),
                HttpStatus.OK);
    }

    @Override
    public ResponseEntity<GenericResponse<Object>> getAllPCAUser() {
        List<PcaListDetails> response = userService.getAllPCAUsers();
        return new ResponseEntity<>(new GenericResponse<>(response, Constants.SUCCESS, HttpStatus.OK.value()),
                HttpStatus.OK);
    }

    @Override
    public ResponseEntity<GenericResponse<Object>> getPCADetailsById(Integer pcaId) {
        PcaPersonalDetails response = userService.getPCADetailsById(pcaId);
        return new ResponseEntity<>(new GenericResponse<>(response, Constants.SUCCESS, HttpStatus.OK.value()),
                HttpStatus.OK);
    }

    @Override
    public ResponseEntity<GenericResponse<Object>> getAllRolesCount() {
        HashMap<Object , Object> response = userService.getCountForAllRoles();
        return new ResponseEntity<>(new GenericResponse<>(response , Constants.SUCCESS , HttpStatus.OK.value()), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<GenericResponse<Object>> updateSuperAdminProfile(SuperAdminProfile superAdminProfile) {
        userService.updateSuperAdminProfile(superAdminProfile);
        return new ResponseEntity<>(new GenericResponse<>(Constants.PROFILE_UPDATED , Constants.SUCCESS , HttpStatus.OK.value()), HttpStatus.OK);

    }
}
