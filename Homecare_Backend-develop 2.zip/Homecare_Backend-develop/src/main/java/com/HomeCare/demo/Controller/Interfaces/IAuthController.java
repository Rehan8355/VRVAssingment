package com.HomeCare.demo.Controller.Interfaces;


import com.HomeCare.demo.Model.ChangePasswordRequest;
import com.HomeCare.demo.Model.LoginRequest;
import com.HomeCare.demo.Model.PasswordResetRequest;
import com.HomeCare.demo.Model.ResponseModel.GenericResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/admin")
public interface IAuthController {

    @PostMapping("/login")
    ResponseEntity<GenericResponse<Object>> loginUser(@RequestBody LoginRequest loginRequest);

    @PatchMapping("/changePassword")
    ResponseEntity<GenericResponse<Object>> updatePassword(@RequestBody PasswordResetRequest passwordResetRequest);

    @PatchMapping("/resetPassword")
    ResponseEntity<GenericResponse<Object>> resetPassword(@RequestBody ChangePasswordRequest changePasswordRequest);

}
