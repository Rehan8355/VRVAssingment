package com.HomeCare.demo.Controller.Interfaces;


import com.HomeCare.demo.Model.EmailRequest;
import com.HomeCare.demo.Model.OtpVerifyDetails;
import com.HomeCare.demo.Model.ResponseModel.GenericResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/email")
public interface IEmailController {

    @PostMapping("/sendOtpEmail")
    public ResponseEntity<GenericResponse<Object>> sendOtpEmail(@RequestBody EmailRequest emailRequest);

    @PostMapping("/sendMailWithAttachment")
    public ResponseEntity<GenericResponse<String>> sendMailWithAttachment(@RequestBody EmailRequest emailRequest);

    @PostMapping("/verifyOtp")
    public ResponseEntity<GenericResponse<String>> verifyOtp(@RequestBody OtpVerifyDetails otpVerifyDetails);

}
