package com.HomeCare.demo.Controller.Interfaces;

import com.HomeCare.demo.Model.ResponseModel.GenericResponse;
import com.HomeCare.demo.Model.SuperAdminProfile;
import com.HomeCare.demo.Model.UserDetails;
import org.apache.coyote.Response;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/user")
public interface IUserController {

    @PostMapping("/create_pca_user")
    ResponseEntity<?> createNewUser(@RequestBody UserDetails userDetails);

    @GetMapping("/PCA")
    ResponseEntity<GenericResponse<Object>> getAllPCAUser();

    @GetMapping("/PCA/{pcaId}")
    ResponseEntity<GenericResponse<Object>> getPCADetailsById(@PathVariable Integer pcaId);

    @GetMapping("/count")
    ResponseEntity<GenericResponse<Object>> getAllRolesCount();

    @PatchMapping("/updateProfile")
    ResponseEntity<GenericResponse<Object>> updateSuperAdminProfile(@RequestBody SuperAdminProfile superAdminProfile);
}
