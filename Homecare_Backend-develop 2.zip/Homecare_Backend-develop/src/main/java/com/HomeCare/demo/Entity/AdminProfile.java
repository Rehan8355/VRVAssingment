package com.HomeCare.demo.Entity;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "admin_profile")
public class AdminProfile {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "mobile_country_code")
    private String countryCode;

    @Column(name = "user_employment_status")
    private Boolean employmentStatus;

    @Column(name = "employee_assessment_id")
    private String employeeAssessmentId;

    @Column(name = "social_security_number")
    private String socialSecurityNumber;

    @Column(name = "employee_code")
    private String employeeCode;

    @Column(name = "emergency_contact_name")
    private String emergencyContactName;

    @Column(name = "emergency_contact_number")
    private String emergencyContactNumber;

    @Column(name = "emergency_contact_country_code")
    private String emergencyContactCountryCode;

    @Column(name = "user_address")
    private String userAddress;

    @Column(name = "city")
    private String city;

    @Column(name = "state")
    private String state;

    @Column(name = "country")
    private String country;

    @Column(name = "zip_code")
    private Integer zipCode;

    @Column(name = "user_id")
    private Long userId;

    @Column(name = "created_by")
    private Long createdBy;

    @Column(name = "permission_granted")
    private Boolean permissionGranted;

    @Column(name = "permission_granted_to")
    private Long authorizedTo;
}
