package com.HomeCare.demo.Entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "role_master")
@Data
public class RoleMaster {

    @Id
    private Long roleId;

    @Column(name = "role_name")
    private String roleName;

    @Column(name = "role_status")
    private Boolean roleStatus;

}
