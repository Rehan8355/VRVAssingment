package com.HomeCare.demo.Entity;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import lombok.Data;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "user_master")
public class UserMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long userId;

    @Column(name = "user_first_name")
    private String userFirstName;

    @Column(name = "user_last_name")
    private String userLastName;

    @Column(name = "user_password")
    private String userPassword;

    @Column(name = "user_email")
    private String userEmail;

    @Column(name = "user_mobile_no")
    private String userMobileNo;

    @Column(name = "user_dob")
    private String dateOfBirth;

    @Column(name = "user_hire_date")
    private LocalDate userHireDate;

    @Column(name = "user_status")
    private Boolean userStatus;

    @ManyToOne
    @JoinColumn(name = "role_id", referencedColumnName = "roleId")
    @JsonManagedReference
    private RoleMaster role;

    private Boolean isFirstLogin;

    @CreationTimestamp
    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    @Column(name = "modified_at")
    private LocalDateTime modifiedAt;
}
