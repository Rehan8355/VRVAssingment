package com.HomeCare.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HomeCareApplication {

	public static void main(String[] args) {
		SpringApplication.run(HomeCareApplication.class, args);
	}

}
