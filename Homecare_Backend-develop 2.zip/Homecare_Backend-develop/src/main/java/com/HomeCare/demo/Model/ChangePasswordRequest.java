package com.HomeCare.demo.Model;

import lombok.Data;

@Data
public class ChangePasswordRequest {
    private String userEmail;
    private String currentPassword;
    private String newPassword;
}
