package com.HomeCare.demo.Model;

import lombok.Data;

@Data
public class OtpVerifyDetails {
    private String hashedOtp;
    private String currentOtp;
    private Long expiryTime;
}
