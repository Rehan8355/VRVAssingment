package com.HomeCare.demo.Model;

import lombok.Data;

@Data
public class PasswordResetRequest {
    private String userEmail;
    private String userPasswordChange;
}
