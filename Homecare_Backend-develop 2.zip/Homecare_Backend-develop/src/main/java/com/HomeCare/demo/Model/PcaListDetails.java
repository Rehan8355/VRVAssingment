package com.HomeCare.demo.Model;

import lombok.Data;

@Data
public class PcaListDetails {
    private Long userId;
    private String userFullName;
    private String userMobileNumber;
    private Long documentSubmitted;
    private Integer clients;
}
