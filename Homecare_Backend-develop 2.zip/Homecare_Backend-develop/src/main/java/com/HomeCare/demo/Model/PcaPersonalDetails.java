package com.HomeCare.demo.Model;

import lombok.Data;

import java.time.LocalDate;

@Data
public class PcaPersonalDetails {

    private Long pcaUserId;
    private String fullName;
    private String employeeId;
    private String Phone;
    private String email;
    private String employeeAssessmentId;
    private String employeeCode;
    private String SSN;
    private LocalDate hireDate;
    private String address;
    private String emergencyContactName;
    private String emergencyContactNumber;
}
