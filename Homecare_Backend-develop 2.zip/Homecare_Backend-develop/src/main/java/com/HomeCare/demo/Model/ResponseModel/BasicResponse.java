package com.HomeCare.demo.Model.ResponseModel;

import lombok.Data;

@Data
public class BasicResponse {
    private Integer status;
    private String message;
}
