package com.HomeCare.demo.Model.ResponseModel;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
//@JsonInclude(JsonInclude.Include.NON_NULL)
public class GenericResponse<T> {
    private T data;
    private String  message;
    private Integer status;

    public GenericResponse(Integer status , String message){
        this.status = status;
        this.message = message;
    }
}
