package com.HomeCare.demo.Model.ResponseModel;

import com.HomeCare.demo.Entity.RoleMaster;
import lombok.Data;

import java.time.LocalDate;

@Data
public class LoginResponse {
    private Long userId;
    private String userFirstName;
    private String userLastName;
    private String userEmail;
    private String userMobile;
    private String userDOB;
    private Boolean userStatus;
    private RoleMaster role;
    private Boolean isFirstLogin;
    private String userAddress;
    private LocalDate userHireDate;

}
