package com.HomeCare.demo.Model;

import lombok.Data;

@Data
public class SuperAdminProfile {
    private Long userId;
    private String userFirstName;
    private String userLastName;
    private String userPhoneNumber;
    private String userDob;
    private String userAddress;
}
