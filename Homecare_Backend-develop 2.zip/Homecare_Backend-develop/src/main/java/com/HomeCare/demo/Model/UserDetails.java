package com.HomeCare.demo.Model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import java.time.LocalDate;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class UserDetails {

    private String userFirstName;

    private String userLastName;

    private String userPassword;

    private String userEmail;

    private String userMobileNo;

    private String countryCode;

    private String dateOfBirth;

    private Boolean employmentStatus;

    private String employeeAssessmentId;

    private String socialSecurityNumber;

    private LocalDate userHireDate;

    private String employeeCode;

    private String emergencyContactName;

    private String emergencyContactNumber;

    private String emergencyContactCountryCode;

    private String userAddress;

    private String city;

    private String state;

    private String country;

    private Integer zipCode;

    private Long userRole;

    private Long createdBy;
}
