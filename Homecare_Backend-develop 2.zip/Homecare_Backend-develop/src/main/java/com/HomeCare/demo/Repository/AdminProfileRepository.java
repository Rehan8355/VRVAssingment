package com.HomeCare.demo.Repository;


import com.HomeCare.demo.Entity.AdminProfile;
import com.HomeCare.demo.Entity.RoleMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface AdminProfileRepository extends JpaRepository<AdminProfile, Long> {
    @Query("SELECT ap FROM AdminProfile ap WHERE ap.userId = :userId")
    AdminProfile findByUserId(@Param("userId") Long userId);
}

