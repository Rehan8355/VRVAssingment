package com.HomeCare.demo.Repository;


import com.HomeCare.demo.Entity.RoleMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface RoleMasterRepository extends JpaRepository<RoleMaster, Long> {

    @Query("SELECT rm FROM RoleMaster rm WHERE rm.roleId = :roleId")
    RoleMaster findByRoleId(@Param("roleId") Long roleId);
}
