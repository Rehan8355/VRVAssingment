package com.HomeCare.demo.Repository;


import com.HomeCare.demo.Entity.UserMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserRepository extends JpaRepository<UserMaster, Long> {

    @Query("SELECT u FROM UserMaster u WHERE u.userEmail = :email AND u.userStatus = :userStatus")
    UserMaster findByEmailAndActive(@Param("email") String email , @Param("userStatus") Boolean userStatus);

    @Query("SELECT u FROM UserMaster u WHERE u.role.roleId = :roleId")
    List<UserMaster> findAllByRoleId(@Param("roleId") Long roleId);

    @Query("SELECT u FROM UserMaster u WHERE u.userEmail = :userEmail")
    UserMaster findUserByEmailId(@Param("userEmail") String userEmail);

    @Query("SELECT u.role.roleName, COUNT(u.role.roleId) " +
            "FROM UserMaster u " +
            "WHERE u.role.roleId != 1 " +
            "GROUP BY u.role.roleName " +
            "ORDER BY u.role.roleName")
    List<Object[]> findRoleWiseUserCount();

    @Query("SELECT um FROM UserMaster um WHERE um.userId = :userId AND um.userStatus = :userStatus")
    UserMaster findUserByIdAndActive(@Param("userId") Long userId , @Param("userStatus") Boolean userStatus);


}
