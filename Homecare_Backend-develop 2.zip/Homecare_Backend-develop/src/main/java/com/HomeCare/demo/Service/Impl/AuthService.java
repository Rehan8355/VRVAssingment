package com.HomeCare.demo.Service.Impl;

import com.HomeCare.demo.Entity.AdminProfile;
import com.HomeCare.demo.Entity.UserMaster;
import com.HomeCare.demo.Model.ChangePasswordRequest;
import com.HomeCare.demo.Model.LoginRequest;
import com.HomeCare.demo.Model.PasswordResetRequest;
import com.HomeCare.demo.Model.ResponseModel.LoginResponse;
import com.HomeCare.demo.Repository.AdminProfileRepository;
import com.HomeCare.demo.Repository.UserRepository;
import com.HomeCare.demo.Service.Interfaces.AuthInterface;
import com.HomeCare.demo.Utils.Constants;
import com.HomeCare.demo.Utils.Exceptions.BadRequestException;
import com.HomeCare.demo.Utils.Exceptions.NotFoundException;
import com.HomeCare.demo.Utils.Exceptions.UnauthorizedException;
import com.HomeCare.demo.Utils.JwtUtil;
import com.HomeCare.demo.Utils.PasswordHashing;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Objects;

@Service
public class AuthService implements AuthInterface {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private JwtUtil jwtUtil;
    @Autowired
    private AdminProfileRepository adminProfileRepository;

    @Override
    public HashMap<String, Object> loginAuthUser(LoginRequest loginRequest) {

        HashMap<String , Object> responseMap = new HashMap<>();
        String token , refreshToken;
        Long role;

        UserMaster existingUser = userRepository.findByEmailAndActive(loginRequest.getEmail(),true);
        AdminProfile adminProfile = adminProfileRepository.findByUserId(existingUser.getUserId());

        if(existingUser == null){
            throw new NotFoundException(Constants.EMAIL_NOT_EXIST);
        }

        LoginResponse loginResponse = getLoginResponse(existingUser, adminProfile);

        if (Objects.nonNull(existingUser)) {
            role = existingUser.getRole().getRoleId();
            String hashedPassword = PasswordHashing.sha3256Algo(loginRequest.getPassword());
            if (Objects.equals(hashedPassword, existingUser.getUserPassword())) {
                token = jwtUtil.generateToken(existingUser.getUserId() , existingUser.getUserEmail() , role , existingUser.getUserFirstName() + " " +existingUser.getUserLastName());
                refreshToken = jwtUtil.generateRefreshToken(existingUser.getUserId(), existingUser.getUserEmail(), role, existingUser.getUserFirstName() + " " +existingUser.getUserLastName());
            } else {
                throw new UnauthorizedException(Constants.PASSWORD_INCORRECT);
            }
        } else {
            throw new NotFoundException(Constants.EMAIL_NOT_EXIST);
        }


        responseMap.put("token",token);
        responseMap.put("refresh_token",refreshToken);
        responseMap.put("UserDetails",loginResponse);

        return responseMap;

    }

    private static LoginResponse getLoginResponse(UserMaster existingUser, AdminProfile adminProfile) {
        LoginResponse loginResponse = new LoginResponse();
        loginResponse.setIsFirstLogin(existingUser.getIsFirstLogin());
        loginResponse.setRole(existingUser.getRole());
        loginResponse.setUserId(existingUser.getUserId());
        loginResponse.setUserDOB(existingUser.getDateOfBirth());
        loginResponse.setUserEmail(existingUser.getUserEmail());
        loginResponse.setUserMobile(existingUser.getUserMobileNo());
        loginResponse.setUserStatus(existingUser.getUserStatus());
        loginResponse.setUserLastName(existingUser.getUserLastName());
        loginResponse.setUserFirstName(existingUser.getUserFirstName());
        loginResponse.setUserAddress(adminProfile.getUserAddress());
        loginResponse.setUserHireDate(existingUser.getUserHireDate());
        return loginResponse;
    }

    @Override
    public void changePassword(PasswordResetRequest passwordResetRequest) {

        UserMaster existingUser = userRepository.findByEmailAndActive(passwordResetRequest.getUserEmail(), true);

        if(Objects.nonNull(existingUser)){
            String newPassword = passwordResetRequest.getUserPasswordChange();
            String updateHashedPassword = PasswordHashing.sha3256Algo(newPassword);

            existingUser.setUserPassword(updateHashedPassword);
            userRepository.save(existingUser);
        }
        else{
            throw new NotFoundException(Constants.EMAIL_NOT_EXIST);
        }
    }

    @Override
    public void resetPassword(ChangePasswordRequest passwordChangeRequest) {

        UserMaster existingUser = userRepository.findByEmailAndActive(passwordChangeRequest.getUserEmail(), true);

        if(Objects.nonNull(existingUser)){

            String hashedPassword = PasswordHashing.sha3256Algo(passwordChangeRequest.getCurrentPassword());

            if(!hashedPassword.equals(existingUser.getUserPassword())){
                throw new NotFoundException(Constants.PASSWORD_INCORRECT);
            }
            String newHashedPassword = PasswordHashing.sha3256Algo(passwordChangeRequest.getNewPassword());

            if(newHashedPassword.equals(hashedPassword)){
                throw new NotFoundException(Constants.PASSWORD_SIMILAR);
            }
            existingUser.setUserPassword(newHashedPassword);

            userRepository.save(existingUser);
        }
        else{
            throw new NotFoundException(Constants.EMAIL_NOT_EXIST);
        }
    }
}
