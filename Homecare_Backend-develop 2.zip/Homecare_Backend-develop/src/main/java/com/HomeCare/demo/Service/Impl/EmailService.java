package com.HomeCare.demo.Service.Impl;

import com.HomeCare.demo.Entity.UserMaster;
import com.HomeCare.demo.Model.EmailRequest;
import com.HomeCare.demo.Model.LoginRequest;
import com.HomeCare.demo.Model.OtpVerifyDetails;
import com.HomeCare.demo.Repository.UserRepository;
import com.HomeCare.demo.Service.Interfaces.EmailInterface;
import com.HomeCare.demo.Utils.Constants;
import com.HomeCare.demo.Utils.Exceptions.NotFoundException;
import com.HomeCare.demo.Utils.Exceptions.UnauthorizedException;
import com.HomeCare.demo.Utils.PasswordHashing;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.io.File;
import java.time.Instant;
import java.util.HashMap;
import java.util.Objects;
import java.util.Random;

@Service
public class EmailService implements EmailInterface {

    @Autowired
    private JavaMailSender javaMailSender;

    @Value("${spring.mail.username}")
    private String sender;
    @Autowired
    private UserRepository userRepository;

    @Override
    public HashMap<String , Object> sendOtp(EmailRequest details) {
        HashMap<String , Object> responseMap = new HashMap<>();

        UserMaster user = userRepository.findUserByEmailId(details.getRecipient());
        if(Objects.isNull(user)){
            throw new NotFoundException(Constants.EMAIL_NOT_EXIST);
        }
        try {

            SimpleMailMessage mailMessage = new SimpleMailMessage();
            String decodedOtp = generateOtp();

            String hashedOtp = PasswordHashing.sha3256Algo(decodedOtp);

            mailMessage.setFrom(sender);
            mailMessage.setTo(details.getRecipient());
            mailMessage.setText(details.getMsgBody()+"   " +decodedOtp);
            mailMessage.setSubject(details.getSubject());

            long expiryTimeInEpoch = Instant.now().plusSeconds(60).getEpochSecond();

            responseMap.put("hashed_otp",hashedOtp);
            responseMap.put("recipient",details.getRecipient());
            responseMap.put("expiry_time",expiryTimeInEpoch);

            javaMailSender.send(mailMessage);
            return responseMap;
        }
        catch (Exception e) {
            responseMap.put("Issue", Constants.ERROR_SENDING_EMAIL);
            responseMap.put("recipient",details.getRecipient());
            return responseMap;
        }
    }

    @Override
    public String sendMailWithAttachment(EmailRequest details) {
        MimeMessage mimeMessage
                = javaMailSender.createMimeMessage();
        MimeMessageHelper mimeMessageHelper;

        try {

            mimeMessageHelper
                    = new MimeMessageHelper(mimeMessage, true);
            mimeMessageHelper.setFrom(sender);
            mimeMessageHelper.setTo(details.getRecipient());
            mimeMessageHelper.setText(details.getMsgBody());
            mimeMessageHelper.setSubject(details.getSubject());

            FileSystemResource file = new FileSystemResource(new File(details.getAttachment()));

            mimeMessageHelper.addAttachment(file.getFilename(), file);

            javaMailSender.send(mimeMessage);
            return Constants.EMAIL_SEND_SUCCESSFULLY;
        }

        catch (MessagingException e) {
            return Constants.ERROR_SENDING_EMAIL;
        }
    }

    @Override
    public String otpVerification(OtpVerifyDetails otpVerifyDetails) {
        String normalOtp = otpVerifyDetails.getCurrentOtp();

        Long currentTime = Instant.now().getEpochSecond();
        String hashedOtp=PasswordHashing.sha3256Algo(normalOtp);

        if(!otpVerifyDetails.getHashedOtp().equals(hashedOtp)){
            throw new UnauthorizedException(Constants.OTP_VERIFICATION_FAILED);
        }
        else if(otpVerifyDetails.getExpiryTime() <= currentTime){
            throw new UnauthorizedException(Constants.OTP_EXPIRED);
        }
        return Constants.OTP_VERIFICATION_SUCCESSFUL;
    }
    @Override
    public String sendCredentials(LoginRequest request) {
        UserMaster existingUser = userRepository.findByEmailAndActive(request.getEmail(), true);

        if(Objects.nonNull(existingUser)){
            SimpleMailMessage mailMessage = new SimpleMailMessage();

            mailMessage.setFrom(sender);
            mailMessage.setTo(request.getEmail());
            mailMessage.setText("Username :"+request.getEmail()+"\n"+"Password :"+request.getPassword());
            mailMessage.setSubject("Login Credential for HomeCare");

            javaMailSender.send(mailMessage);
            return Constants.EMAIL_SEND_SUCCESSFULLY;
        }else{
            throw new NotFoundException(Constants.EMAIL_NOT_EXIST);
        }
    }

    public static String generateOtp() {
        Random random = new Random();
        int otp = 1000 + random.nextInt(9000);
        return String.valueOf(otp);
    }
}
