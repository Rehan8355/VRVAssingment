package com.HomeCare.demo.Service.Impl;


import com.HomeCare.demo.Entity.AdminProfile;
import com.HomeCare.demo.Entity.RoleMaster;
import com.HomeCare.demo.Entity.UserMaster;
import com.HomeCare.demo.Model.*;
import com.HomeCare.demo.Repository.AdminProfileRepository;
import com.HomeCare.demo.Repository.RoleMasterRepository;
import com.HomeCare.demo.Repository.UserRepository;
import com.HomeCare.demo.Service.Interfaces.UserInterface;
import com.HomeCare.demo.Utils.Constants;
import com.HomeCare.demo.Utils.Exceptions.AlreadyExistException;
import com.HomeCare.demo.Utils.Exceptions.NotFoundException;
import com.HomeCare.demo.Utils.PasswordHashing;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


@Service
public class UserService implements UserInterface {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RoleMasterRepository roleMasterRepository;

    @Autowired
    private AdminProfileRepository adminProfileRepository;

    @Autowired
    private EmailService emailService;

    @Override
    public void createUser(UserDetails userDetails) {

        UserMaster newUser = new UserMaster();
        UserMaster existingUser = userRepository.findByEmailAndActive(userDetails.getUserEmail() , true);

        if(existingUser != null){
                throw new AlreadyExistException(Constants.USER_NAME_EXIST);
        }

        newUser.setUserFirstName(userDetails.getUserFirstName());
        newUser.setUserLastName(userDetails.getUserLastName());
        newUser.setUserEmail(userDetails.getUserEmail());
        newUser.setUserStatus(true);

        String encodedPassword = PasswordHashing.sha3256Algo(userDetails.getUserPassword());
        newUser.setUserPassword(encodedPassword);

        newUser.setUserMobileNo(userDetails.getUserMobileNo());
        newUser.setDateOfBirth(userDetails.getDateOfBirth());
        newUser.setUserHireDate(userDetails.getUserHireDate());
        newUser.setIsFirstLogin(false);
        RoleMaster userRoleExists = findUserRole(userDetails.getUserRole());
        newUser.setRole(userRoleExists);

        UserMaster newUserRecord =userRepository.save(newUser);

        AdminProfile newProfile = new AdminProfile();

        newProfile.setCountryCode(userDetails.getCountryCode());
        newProfile.setEmploymentStatus(userDetails.getEmploymentStatus());
        newProfile.setEmployeeAssessmentId(userDetails.getEmployeeAssessmentId());
        newProfile.setSocialSecurityNumber(userDetails.getSocialSecurityNumber());
        newProfile.setEmployeeCode(userDetails.getEmployeeCode());
        newProfile.setEmergencyContactName(userDetails.getEmergencyContactName());
        newProfile.setEmergencyContactNumber(userDetails.getEmergencyContactNumber());
        newProfile.setEmergencyContactCountryCode(userDetails.getEmergencyContactCountryCode());
        newProfile.setUserAddress(userDetails.getUserAddress());
        newProfile.setCity(userDetails.getCity());
        newProfile.setState(userDetails.getState());
        newProfile.setCountry(userDetails.getCountry());
        newProfile.setZipCode(userDetails.getZipCode());
        newProfile.setUserId(newUserRecord.getUserId());
        newProfile.setCreatedBy(userDetails.getCreatedBy());
        newProfile.setPermissionGranted(false);
        newProfile.setAuthorizedTo(null);

        adminProfileRepository.save(newProfile);

        LoginRequest request = new LoginRequest();
        request.setEmail(userDetails.getUserEmail());
        request.setPassword(userDetails.getUserPassword());

        ExecutorService executorService = Executors.newSingleThreadExecutor();
        executorService.execute(() -> {
            emailService.sendCredentials(request);
        });
        executorService.shutdown();

    }

    RoleMaster findUserRole(Long role){
        RoleMaster roleValue = roleMasterRepository.findByRoleId(role);
        if (role == null) {
            throw new NotFoundException(Constants.USER_ROLE_DOES_NOT_EXISTS);
        }
        return roleValue;
    }

    @Override
    public List<PcaListDetails> getAllPCAUsers() {
        List<UserMaster> pcaUsers = userRepository.findAllByRoleId(3L);

        if(ObjectUtils.isEmpty(pcaUsers)){
            throw new NotFoundException(Constants.PCA_LIST_EMPTY);
        }

        return pcaUsers.stream().map(user->{
            PcaListDetails details = new PcaListDetails();
            details.setUserId(user.getUserId());
            details.setUserFullName(user.getUserFirstName()+" "+user.getUserLastName());
            details.setUserMobileNumber(user.getUserMobileNo());
            details.setClients(getClients());
            details.setDocumentSubmitted(getDocumentSubmissionStatus(user.getUserId()));
            return details;
        }).toList();
    }

    @Override
    public PcaPersonalDetails getPCADetailsById(Integer userId) {

        int intValue = userId;
        long longId = intValue;

        UserMaster userExist = userRepository.findById(longId).orElse(null);

        if(Objects.isNull(userExist)){
            throw new NotFoundException(Constants.PCA_DETAILS_NULL);
        }
        AdminProfile userProfile = adminProfileRepository.findByUserId(longId);

        PcaPersonalDetails personalDetails = new PcaPersonalDetails();
        personalDetails.setPcaUserId(userExist.getUserId());
        personalDetails.setFullName(userExist.getUserFirstName()+ " "+userExist.getUserLastName());
        personalDetails.setAddress(userProfile.getUserAddress());
        personalDetails.setSSN(userProfile.getSocialSecurityNumber());
        personalDetails.setPhone(userExist.getUserMobileNo());
        personalDetails.setEmergencyContactName(userProfile.getEmergencyContactName());
        personalDetails.setEmergencyContactNumber(userProfile.getEmergencyContactName());
        personalDetails.setEmployeeId(userProfile.getEmployeeAssessmentId());
        personalDetails.setHireDate(userExist.getUserHireDate());
        personalDetails.setEmail(userExist.getUserEmail());
        personalDetails.setEmployeeAssessmentId(userProfile.getEmployeeAssessmentId());
        personalDetails.setEmployeeCode(userProfile.getEmployeeCode());

        return personalDetails;
    }
    @Override
    public HashMap<Object, Object> getCountForAllRoles() {
        HashMap<Object , Object> response = new HashMap<>();
        List<Object[]> roleCounts = userRepository.findRoleWiseUserCount();

        roleCounts.stream().map(element ->{
            response.put(element[0], element[1]);
            return response;
        }).toList();

        return response;
    }

    @Override
    public void updateSuperAdminProfile(SuperAdminProfile superAdminProfile) {
        UserMaster existingUser = userRepository.findUserByIdAndActive(superAdminProfile.getUserId() , true);
        AdminProfile adminProfile = adminProfileRepository.findByUserId(superAdminProfile.getUserId());

        if(Objects.nonNull(existingUser)){

                existingUser.setUserFirstName(superAdminProfile.getUserFirstName());
                existingUser.setUserLastName(superAdminProfile.getUserLastName());
                existingUser.setUserMobileNo(superAdminProfile.getUserPhoneNumber());
                existingUser.setDateOfBirth(superAdminProfile.getUserDob());

            userRepository.save(existingUser);

                adminProfile.setUserAddress(superAdminProfile.getUserAddress());
            adminProfileRepository.save(adminProfile);
        }
        else{
            throw new NotFoundException(Constants.EMAIL_NOT_EXIST);
        }
    }

    public Long getDocumentSubmissionStatus(Long userId){
        Optional<AdminProfile> adminUser = adminProfileRepository.findById(userId);

        if(!Objects.nonNull(adminUser)){
            throw new NotFoundException(Constants.EMAIL_NOT_EXIST);
        }
        Long adminDocuments = adminUser.get().getId();
        return adminDocuments;
    }

    public Integer getClients(){
        List<UserMaster> pcaUsers = userRepository.findAllByRoleId(4L);
        return pcaUsers.size();
    }

}
