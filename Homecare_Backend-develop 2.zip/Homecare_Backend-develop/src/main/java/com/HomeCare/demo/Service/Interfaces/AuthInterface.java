package com.HomeCare.demo.Service.Interfaces;


import com.HomeCare.demo.Model.ChangePasswordRequest;
import com.HomeCare.demo.Model.LoginRequest;
import com.HomeCare.demo.Model.PasswordResetRequest;
import org.springframework.stereotype.Service;

import java.util.HashMap;

@Service
public interface AuthInterface {
    HashMap<String, Object> loginAuthUser(LoginRequest loginRequest);

    void changePassword(PasswordResetRequest passwordResetRequest);

    void resetPassword(ChangePasswordRequest passwordChangeRequest);
}
