package com.HomeCare.demo.Service.Interfaces;



import com.HomeCare.demo.Model.EmailRequest;
import com.HomeCare.demo.Model.LoginRequest;
import com.HomeCare.demo.Model.OtpVerifyDetails;

import java.util.HashMap;

public interface EmailInterface {

    HashMap<String , Object> sendOtp(EmailRequest details);

    String sendMailWithAttachment(EmailRequest details);

    String otpVerification(OtpVerifyDetails otpVerifyDetails);

    String sendCredentials(LoginRequest request);
}
