package com.HomeCare.demo.Service.Interfaces;


import com.HomeCare.demo.Model.PcaListDetails;
import com.HomeCare.demo.Model.PcaPersonalDetails;
import com.HomeCare.demo.Model.SuperAdminProfile;
import com.HomeCare.demo.Model.UserDetails;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;

@Service
public interface UserInterface {

   void createUser(UserDetails userDetails);

   List<PcaListDetails> getAllPCAUsers();

   PcaPersonalDetails getPCADetailsById(Integer userId);

   HashMap<Object , Object> getCountForAllRoles();

   void updateSuperAdminProfile(SuperAdminProfile superAdminProfile);
}
