package com.HomeCare.demo.Utils;

public interface Constants {
    String AUTHORIZATION = "Authorization";
    String SUCCESS = "Success";
    String FAILURE = "Failure";
    String ACCESS_DENIED = "Access Denied , Not permitted to perform this action.";
    String USER_NAME_EXIST = "This user name already exist";
    String USER_ROLE_DOES_NOT_EXISTS = "This role does not exists";
    String USER_CREATED_SUCCESSFULLY = "User Created Successfully.";
    String EMAIL_NOT_EXIST = "This user does not exist";
    String INVALID_CREDENTIALS = "User credentials are incorrect.";
    String AUTHORIZATION_FAILED = "Your are not authorized.";
    String PASSWORD_INCORRECT = "Password provided is incorrect";
    String SUCCESSFULLY_LOGIN = "Successfully logged in.";
    String EMAIL_SEND_SUCCESSFULLY = "Email Send Successfully.";
    String ERROR_SENDING_EMAIL = "Error while sending email.";
    String OTP_VERIFICATION_SUCCESSFUL = "Otp verification successful";
    String OTP_VERIFICATION_FAILED = "Otp verification failed";
    String OTP_EXPIRED = "Otp is Expired, please try again";
    String PASSWORD_CHANGED_SUCCESSFULLY = "Password changed successfully";
    String PCA_LIST_EMPTY = "PCA List is empty";
    String PCA_DETAILS_NULL = "PCA details does not exists";
    String PASSWORD_SIMILAR = "New and Old password cannot be same";
    String PROFILE_UPDATED = "Profile updated successfully.";


}
