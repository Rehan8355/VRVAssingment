package com.HomeCare.demo.Utils.Exceptions;

import org.apache.coyote.BadRequestException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;

import java.util.HashMap;
import java.util.Map;

@ControllerAdvice
public class ExceptionHandler {

    @org.springframework.web.bind.annotation.ExceptionHandler(value = AlreadyExistException.class)
    public ResponseEntity<com.HomeCare.demo.Utils.Exceptions.ExceptionResponse> alreadyExistExceptionHandler(AlreadyExistException exception) {
        return new ResponseEntity<>(new com.HomeCare.demo.Utils.Exceptions.ExceptionResponse<>(HttpStatus.BAD_REQUEST,
                exception.getLocalizedMessage(), exception), HttpStatus.BAD_REQUEST);
    }

    @org.springframework.web.bind.annotation.ExceptionHandler(value = com.HomeCare.demo.Utils.Exceptions.UnauthorizedException.class)
    public ResponseEntity<com.HomeCare.demo.Utils.Exceptions.ExceptionResponse> unauthorizedExceptionHandler(com.HomeCare.demo.Utils.Exceptions.UnauthorizedException exception) {
        return new ResponseEntity<>(new com.HomeCare.demo.Utils.Exceptions.ExceptionResponse<>(HttpStatus.UNAUTHORIZED,
                exception.getLocalizedMessage(), exception), HttpStatus.UNAUTHORIZED);
    }

    @org.springframework.web.bind.annotation.ExceptionHandler(value = BadRequestException.class)
    public ResponseEntity<com.HomeCare.demo.Utils.Exceptions.ExceptionResponse> badRequestExceptionHandler(BadRequestException exception) {
        return new ResponseEntity<>(new com.HomeCare.demo.Utils.Exceptions.ExceptionResponse<>(HttpStatus.BAD_REQUEST,
                exception.getLocalizedMessage(), exception), HttpStatus.BAD_REQUEST);
    }

    @org.springframework.web.bind.annotation.ExceptionHandler(value = NotFoundException.class)
    public ResponseEntity<com.HomeCare.demo.Utils.Exceptions.ExceptionResponse> notFoundExceptionHandler(NotFoundException exception) {
        return new ResponseEntity<>(new com.HomeCare.demo.Utils.Exceptions.ExceptionResponse<>(HttpStatus.NOT_FOUND,
                exception.getLocalizedMessage(), exception), HttpStatus.NOT_FOUND);
    }

    @org.springframework.web.bind.annotation.ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Map<String, String>> handleValidationExceptions(MethodArgumentNotValidException ex) {
        Map<String, String> errors = new HashMap<>();
        ex.getBindingResult().getFieldErrors().forEach(error -> {
            errors.put(error.getField(), error.getDefaultMessage());
        });
        return new ResponseEntity<>(errors, HttpStatus.BAD_REQUEST);
    }

    //General exception handler as a fallback
    @org.springframework.web.bind.annotation.ExceptionHandler(value = Exception.class)
    public ResponseEntity<com.HomeCare.demo.Utils.Exceptions.ExceptionResponse> handleGenericException(Exception exception) {
        String message = "An unexpected error occurred: " + exception.getMessage();
        return new ResponseEntity<>(new com.HomeCare.demo.Utils.Exceptions.ExceptionResponse<>(HttpStatus.INTERNAL_SERVER_ERROR,
                message, exception), HttpStatus.INTERNAL_SERVER_ERROR);
    }
}
