package com.HomeCare.demo.Utils.Exceptions;

import lombok.Data;
import org.springframework.http.HttpStatus;

@Data
public class ExceptionResponse<T> {


    public int statusCode;
    public String message;
    public String debugMessage;

    ExceptionResponse(String message, Throwable ex) {
        this(HttpStatus.BAD_REQUEST,message,ex);
    }


    public ExceptionResponse(HttpStatus status, String message, Throwable debugMessage){
        this.statusCode = status.value();
        this.message = message;
        this.debugMessage = debugMessage.getLocalizedMessage();
    }
}
