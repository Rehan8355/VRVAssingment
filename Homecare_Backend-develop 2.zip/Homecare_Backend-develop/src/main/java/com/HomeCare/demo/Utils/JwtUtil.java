package com.HomeCare.demo.Utils;


import com.HomeCare.demo.Config.Security.JwtTokenHolder;
import com.HomeCare.demo.Utils.Exceptions.BadRequestException;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import jakarta.annotation.PostConstruct;
import org.apache.tomcat.util.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Component;

import javax.crypto.spec.SecretKeySpec;
import java.security.Key;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Component
public class JwtUtil {

    Logger logger = LoggerFactory.getLogger(JwtUtil.class);
    @Value("${jwt.token.validity}")
    private long tokenValidity;

    @Value("${jwt.refresh.token.validity}")
    private long refreshTokenValidity;

    @Value("${jwt.secret}")
    private String SecretKey;


    private Key key;

    @PostConstruct
    public void init() {
        byte[] encodedKey = Base64.decodeBase64(SecretKey);
        this.key = new SecretKeySpec(encodedKey, 0, encodedKey.length, "HmacSHA512");
    }
    public Claims getAllClaimsFromToken(String token) {
        Claims body = Jwts.parserBuilder().setSigningKey(key).build().parseClaimsJws(token).getBody();
        return body;
    }

    public String generateToken(Long id, String username, Long role, String name) {
        return getToken(id, username, role, "access", tokenValidity, name);
    }


    public String getUsernameFromToken(String token) {
        return getAllClaimsFromToken(token).get("username").toString();
    }

    public String getNameFromToken(String token) {
        return getAllClaimsFromToken(token).get("name").toString();
    }

    public Long getIdFromToken(String token) {
        return Long.valueOf(getAllClaimsFromToken(token).get("id").toString());
    }

    public Long getCurrentUserId() {
        String token = JwtTokenHolder.fetchToken();

        if (token != null && !token.isEmpty()) {
            return getIdFromToken(token);
        }
        throw new BadRequestException(com.HomeCare.demo.Utils.Constants.AUTHORIZATION_FAILED);
    }

    private boolean isTokenExpired(String token) {
        return this.getAllClaimsFromToken(token).getExpiration().before(new Date());
    }

    public String generateRefreshToken(Long id, String username, Long rol, String name) {
        return getToken(id, username, rol, "refresh", refreshTokenValidity, name);
    }

    public boolean isThisRole(String token, String role) {
        Claims claims = this.getAllClaimsFromToken(token);
        return claims.get("role", String.class).equals(role);
    }

    public boolean isInvalid(String token) {
        return this.isTokenExpired(token);
    }

    public Boolean validateToken(String jwtToken, User userDetails) {
        final String username = getUsernameFromToken(jwtToken);
        return (username.equals(userDetails.getUsername()) && !isTokenExpired(jwtToken));
    }

    public Long getExpirationDateFromToken(String token) {
        return this.getAllClaimsFromToken(token).getExpiration().getTime();
    }

    public String getRoleFromToken(String token) {
        return getAllClaimsFromToken(token).get("role").toString();
    }

    public String getTypeFromToken(String token) {
        return getAllClaimsFromToken(token).get("type").toString();
    }

    private String getToken(Long id, String username, Long rol, String refresh, long refreshTokenValidity, String name) {
        Map<String, Object> claims = new HashMap<>();
        claims.put("id", id);
        claims.put("username", username);
        claims.put("name", name);
        claims.put("role", rol);
        claims.put("type", refresh);

        long nowMillis = System.currentTimeMillis();
        long expMillis = nowMillis + refreshTokenValidity;

        Date exp = new Date(expMillis);
        if (logger.isDebugEnabled()) {
            logger.debug("Token: " + SecretKey);
            logger.debug("Validity: " + refreshTokenValidity);
        }
        return Jwts.builder().setClaims(claims).setIssuedAt(new Date(nowMillis)).setExpiration(exp)
                .signWith(key, SignatureAlgorithm.HS512).compact();
    }


}
