package com.HomeCare.demo.Utils;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class PasswordHashing {

    public static String getHash(String password, String algorithmType) {
        try {
            MessageDigest messageDigest = MessageDigest.getInstance(algorithmType);
            byte[] array = messageDigest.digest(password.getBytes());
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < array.length; i++) {
                sb.append(Integer.toHexString((array[i] & 0xFF) | 0x100), 1, 3);
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            System.out.println(e.getMessage());
        }
        return null;
    }

    public static String sha3256Algo(String password){

        return getHash(password, "SHA3-256");
    }
}
